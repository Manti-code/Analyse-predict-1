# Analyse_Predict

### Building Functions to Calculate Metrics using Eskom Data.The functions will calculate/analyse data from Eskom.

#### Function 1

Calculates metrics from Eskom Data and returns metrics as a dictionary. Returns the mean,median,minimum value,maximum value,variance and standard deviation.

#### Function 2 

Function that returns a dictionary of the 5 number summary.

#### Function 3 

Function which takes in a date and time and extracts just the date.

#### Function 4

Function returns a dataframe with added column of extracted hashtags from each tweet and with an added column of the municipality mentioned in each tweet.

#### Function 5 

Function that returns the number of tweets per day.

#### Function 6 

Function that splits a sentence into a list of individual words. Outputs a dataframe with a new column of a list of individual words.

#### Function 7 

Function that returns a dataframe with an added column of the tweet without stopwords.

### Contributors

[Manti Mafokwane ](https://github.com/Manti-code/analyse_predict-1)

Callin Reeby

Siyabonga Mtshemla

Jayadhayanandan Ramesh 

Kwazi Mnguni
